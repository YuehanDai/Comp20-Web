<!doctype html>
<?php
echo '{"description":"Sistine Chapel", "coordinates":{"latitude":41.9031,"longitude":12.4544} }';
?>
